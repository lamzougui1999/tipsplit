import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static const supportedLocales = [Locale('en'), Locale('ar')];

  static bool isRTL(Locale l) => l.languageCode.toLowerCase().startsWith('ar');

  static AppLocalizations of(BuildContext context) =>
      Localizations.of<AppLocalizations>(context, AppLocalizations)!;

  static final Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'app_name': 'TipSplit',
      'bill_total': 'Bill Total',
      'tip': 'Tip',
      'total': 'Total',
      'tip_percent': 'Tip %',
      'split': 'Split',
      'split_tip': 'Split Tip',
      'split_total': 'Split Total',
      'round_total': 'Round Total',
      'up': 'Up',
      'down': 'Down',
      'tipping_custom': 'Local Tipping Custom',
      'country': 'Country',
      'settings': 'Settings',
      'ads_note': 'Ads: banner at bottom; one interstitial on first open.',
      'currency': 'Currency',
      'language': 'Language',
      'auto': 'Auto',
      'per_person': 'per person',
      'made_with': 'Made with ❤️',
    },
    'ar': {
      'app_name': 'TipSplit',
      'bill_total': 'إجمالي الفاتورة',
      'tip': 'البقشيش',
      'total': 'الإجمالي',
      'tip_percent': 'نسبة البقشيش',
      'split': 'تقسيم',
      'split_tip': 'بقشيش للفرد',
      'split_total': 'إجمالي للفرد',
      'round_total': 'تقريب الإجمالي',
      'up': 'لأعلى',
      'down': 'لأسفل',
      'tipping_custom': 'عرف البقشيش المحلي',
      'country': 'الدولة',
      'settings': 'الإعدادات',
      'ads_note': 'الإعلانات: بانر أسفل الشاشة + إعلان عند الفتح فقط.',
      'currency': 'العملة',
      'language': 'اللغة',
      'auto': 'تلقائي',
      'per_person': 'لكل شخص',
      'made_with': 'صُنع بحب ❤️',
    }
  };

  String t(String key) => _localizedValues[locale.languageCode]?[key] ??
      _localizedValues['en']![key] ?? key;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();
  @override
  bool isSupported(Locale locale) => ['en', 'ar'].contains(locale.languageCode);
  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);
  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
