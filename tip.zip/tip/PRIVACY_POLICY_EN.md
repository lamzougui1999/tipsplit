# Privacy Policy (Template)

TipSplit shows banner and interstitial ads via Google AdMob. We do not collect personal data.
AdMob may collect anonymous ad‑related identifiers as described in Google's policies.
No user accounts, analytics, or tracking are implemented in the app.
