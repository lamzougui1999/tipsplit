const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 8080;

app.get('/tipping-norms', (req, res) => {
  const file = path.join(__dirname, 'data', 'tipping-norms.json');
  const json = fs.readFileSync(file, 'utf8');
  res.setHeader('Content-Type', 'application/json');
  res.send(json);
});

app.listen(PORT, () => console.log(`TipSplit backend running on :${PORT}`));
