import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ads/ad_helper.dart';
import 'l10n/app_localizations.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _billController = TextEditingController(text: '');
  double _tipPercent = 18.0;
  int _split = 2;
  BannerAd? _banner;
  bool _interstitialShown = false;
  InterstitialAd? _interstitialAd;
  Map<String, dynamic> _norms = {};
  String? _countryCode; // Determined from device locale

  @override
  void initState() {
    super.initState();
    _initAds();
    _loadNorms();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _interstitialShown = prefs.getBool('interstitial_shown') ?? false;
    });
  }

  Future<void> _saveInterstitialShown() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('interstitial_shown', true);
  }

  Future<void> _initAds() async {
    _banner = await AdHelper.createBanner();
    if (!_interstitialShown) {
      InterstitialAd.load(
        adUnitId: AdHelper.interstitialAdUnitId,
        request: const AdRequest(),
        adLoadCallback: InterstitialAdLoadCallback(
          onAdLoaded: (ad) {
            _interstitialAd = ad;
            ad.fullScreenContentCallback = FullScreenContentCallback(
              onAdDismissedFullScreenContent: (_) {
                _interstitialAd?.dispose();
              },
            );
            _showInterstitialOnce();
          },
          onAdFailedToLoad: (error) {
            debugPrint('Failed to load interstitial: $error');
          },
        ),
      );
    }
  }

  void _showInterstitialOnce() async {
    if (_interstitialAd != null && !_interstitialShown) {
      await _saveInterstitialShown();
      _interstitialAd!.show();
      setState(() {
        _interstitialShown = true;
      });
    }
  }

  Future<void> _loadNorms() async {
    // Determine country by locale (fallback to US)
    final locale = Intl.getCurrentLocale();
    final parts = locale.split('_');
    _countryCode = parts.length > 1 ? parts.last.toUpperCase() : 'US';

    final data = await rootBundle.loadString('assets/data/tipping_norms.json');
    setState(() {
      _norms = jsonDecode(data);
    });
  }

  num _parseBill() {
    final text = _billController.text.replaceAll(',', '').trim();
    if (text.isEmpty) return 0;
    return num.tryParse(text) ?? 0;
  }

  void _roundUp() {
    final total = _total();
    final rounded = total.ceilToDouble();
    final bill = _parseBill();
    final newTip = (rounded - bill).clamp(0, double.infinity);
    setState(() {
      _tipPercent = bill == 0 ? 0 : (newTip / bill) * 100;
    });
  }

  void _roundDown() {
    final total = _total();
    final rounded = total.floorToDouble();
    final bill = _parseBill();
    final newTip = (rounded - bill).clamp(0, double.infinity);
    setState(() {
      _tipPercent = bill == 0 ? 0 : (newTip / bill) * 100;
    });
  }

  double _tipAmount() {
    final bill = _parseBill().toDouble();
    return bill * (_tipPercent / 100.0);
  }

  double _total() {
    final bill = _parseBill().toDouble();
    return bill + _tipAmount();
  }

  String _fmtCurrency(num value) {
    final format = NumberFormat.simpleCurrency(locale: Intl.getCurrentLocale());
    return format.format(value);
  }

  @override
  void dispose() {
    _banner?.dispose();
    _interstitialAd?.dispose();
    _billController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context).t;
    final isRTL = AppLocalizations.isRTL(Localizations.localeOf(context));
    final norm = (_countryCode != null && _norms[_countryCode!] != null)
        ? _norms[_countryCode!]
        : _norms['US'];

    final tip = _tipAmount();
    final total = _total();
    final splitTip = _split == 0 ? 0 : tip / _split;
    final splitTotal = _split == 0 ? 0 : total / _split;

    final textAlign = isRTL ? TextAlign.right : TextAlign.left;

    return Directionality(
      textDirection: isRTL ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(t('app_name')),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _card(children: [
                _rowLabelValue(context, t('bill_total'), _currencyField(_billController)),
                const SizedBox(height: 8),
                _rowLabelValue(context, t('tip'), Text(_fmtCurrency(tip), textAlign: textAlign, style: _valueStyle)),
                const SizedBox(height: 8),
                _rowLabelValue(context, t('total'), Text(_fmtCurrency(total), textAlign: textAlign, style: _valueStyle)),
              ]),
              const SizedBox(height: 12),
              _card(children: [
                _sectionLabel(t('tip_percent')),
                Slider(
                  value: _tipPercent.clamp(0, 100),
                  onChanged: (v) => setState(() => _tipPercent = v),
                  min: 0,
                  max: 30,
                  divisions: 30,
                  label: '${_tipPercent.toStringAsFixed(0)}%',
                ),
                _sectionLabel(t('split')),
                Slider(
                  value: _split.toDouble(),
                  onChanged: (v) => setState(() => _split = v.round().clamp(1, 20)),
                  min: 1,
                  max: 20,
                  divisions: 19,
                  label: '$_split',
                ),
                _rowLabelValue(context, t('split_tip'), Text(_fmtCurrency(splitTip), textAlign: textAlign, style: _valueStyle)),
                const SizedBox(height: 8),
                _rowLabelValue(context, t('split_total'), Text(_fmtCurrency(splitTotal), textAlign: textAlign, style: _valueStyle)),
              ]),
              const SizedBox(height: 12),
              _card(children: [
                _sectionLabel(t('round_total')),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _roundDown,
                        child: Text(t('down')),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _roundUp,
                        child: Text(t('up')),
                      ),
                    ),
                  ],
                ),
              ]),
              const SizedBox(height: 12),
              if (norm != null)
                _card(children: [
                  _sectionLabel(t('tipping_custom')),
                  Text(
                    '${t('country')}: ${_countryCode ?? 'US'}  •  ${norm["range"]}\n${norm["notes"]}',
                    textAlign: textAlign,
                  ),
                ]),
              const SizedBox(height: 24),
              Center(child: Text(t('ads_note'), style: const TextStyle(fontSize: 12, color: Colors.grey))),
              const SizedBox(height: 12),
              Center(child: Text(t('made_with'))),
              const SizedBox(height: 70), // space above banner
            ],
          ),
        ),
        bottomNavigationBar: _banner == null
            ? null
            : Container(
                color: Colors.transparent,
                height: _banner!.size.height.toDouble(),
                alignment: Alignment.center,
                child: AdWidget(ad: _banner!),
              ),
      ),
    );
  }

  static const _labelStyle = TextStyle(fontSize: 16, fontWeight: FontWeight.w500);
  static const _valueStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.bold);

  Widget _currencyField(TextEditingController controller) {
    return SizedBox(
      width: 160,
      child: TextField(
        controller: controller,
        textAlign: TextAlign.end,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(
          hintText: '0.00',
          border: OutlineInputBorder(),
          isDense: true,
        ),
        onChanged: (v) => setState(() {}),
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'[0-9\.\,]')),
        ],
      ),
    );
  }

  Widget _rowLabelValue(BuildContext context, String label, Widget value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(child: Text(label, style: _labelStyle)),
        const SizedBox(width: 12),
        value,
      ],
    );
  }

  Widget _card({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(blurRadius: 6, color: Colors.black12)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: children,
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8.0, top: 4),
        child: Text(text, style: _labelStyle),
      );
}
