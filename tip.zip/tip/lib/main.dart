import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'l10n/app_localizations.dart';
import 'home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const TipSplitApp());
}

class TipSplitApp extends StatefulWidget {
  const TipSplitApp({super.key});
  @override
  State<TipSplitApp> createState() => _TipSplitAppState();
}

class _TipSplitAppState extends State<TipSplitApp> {
  Locale? _locale;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TipSplit',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3F51B5)),
        useMaterial3: true,
      ),
      locale: _locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      localeResolutionCallback: (deviceLocale, supported) {
        // Use device locale if supported, otherwise default to English.
        if (deviceLocale != null &&
            supported.any((l) => l.languageCode == deviceLocale.languageCode)) {
          return deviceLocale;
        }
        return const Locale('en');
      },
      home: const HomePage(),
    );
  }
}
